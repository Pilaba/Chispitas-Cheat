-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 22-06-2019 a las 20:12:00
-- Versión del servidor: 10.3.12-MariaDB
-- Versión de PHP: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `chispitas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `ci_sessions`
--

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('ru5g5u83p5kpitd0rr6rkes6b9orpukk', '127.0.0.1', 1550425155, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535303432353135353b),
('fkn0gh9bcfcrnemj4775jvrb4hgte78k', '127.0.0.1', 1550429238, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535303432393233383b),
('858qpksgc6blan0gr5af97q43mdoiudc', '127.0.0.1', 1550429732, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535303432393733323b),
('gjfhm6n4hc1u12l6jg4ctshetrlsu4vf', '127.0.0.1', 1550430127, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535303433303132373b),
('e08h3e49gchfhomjura0p8gpg1r2j0j3', '127.0.0.1', 1550430488, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535303433303438383b),
('3pl1sets3o66050hlnctkijd4r2bpbdh', '127.0.0.1', 1550431141, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535303433313134313b),
('dqg6v9uj0qeodgior161r1mk5cdqhi8v', '127.0.0.1', 1550431905, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535303433313930353b),
('j48m31oimff25gdm2fa962ahg1l6sdnk', '127.0.0.1', 1550431905, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535303433313930353b),
('72ft0rdrcnrbsgpm64jesd3barmthsbl', '127.0.0.1', 1551396510, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535313339363531303b),
('8h7tnevj5g7bdp1up8napq0u8sgd0shj', '127.0.0.1', 1552342917, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323334323931373b),
('gp7mrkjfl4eio5mnpk7d0k1bnai2ft9h', '127.0.0.1', 1552345522, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323334353532323b),
('2vhhnct4i0h61lpieb8lgmf9hf1bsckb', '127.0.0.1', 1552345824, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323334353832343b),
('a2bfbr3gp9r63hao3nekut2u2bjilr6j', '127.0.0.1', 1552346161, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323334363136313b),
('hhrto4l9edikqbbufephnrcis1rds3et', '127.0.0.1', 1552346493, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323334363439333b),
('25nq6t3llh35e6askp0us8n11amq7rue', '127.0.0.1', 1552346908, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323334363930383b),
('ch3v71jv77aabi3iim7epvqh67vk8je1', '127.0.0.1', 1552348582, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323334383538323b),
('d0ij3khlmm69ep6bgvgvkh9rkcn7dl15', '127.0.0.1', 1552348984, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323334383938343b),
('3cf8gv46mgpog0ovafde0it88d41fig2', '127.0.0.1', 1552349300, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323334393330303b),
('itcdgiao5pqdl2rdkakd4g18gpo00oa0', '127.0.0.1', 1552349675, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323334393637353b),
('cpv3ump44pr8h5q17kif04v5tbqv4689', '127.0.0.1', 1552349978, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323334393937383b),
('0gb6j8hmmfeng8pl3vr38012rnpke9kj', '127.0.0.1', 1552350392, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323335303339323b),
('cpu5oposrfhf1nemabfr7kv79fm0nqa8', '127.0.0.1', 1552350799, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323335303739393b),
('02no3p3fm379vc16c03l8t525jee1a5c', '127.0.0.1', 1552351340, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323335313334303b),
('sgvprklbk07lppseaorq7e2mb07tmb56', '127.0.0.1', 1552353191, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323335333139313b),
('4tts7lofj8e9dfetesemmte59n7i5phm', '127.0.0.1', 1552353506, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323335333530363b),
('70blr3umf41p66aegflncn2k9b7u3hi9', '127.0.0.1', 1552353880, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323335333838303b),
('vg5uhqrocm1rncghqk0751tjv4lqqfsr', '127.0.0.1', 1552354514, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323335343531343b),
('l2oeb7lltmo1m8oddqlpm9ibrrdet4oc', '127.0.0.1', 1552354514, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323335343531343b),
('ididi0l0d2csdcdqt1p4dkrhdq0d67q4', '127.0.0.1', 1552450114, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323435303037353b),
('bdg0f2t20a5n3g671nvre8o2965u3n4g', '127.0.0.1', 1552623323, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535323632333331313b),
('5uf7ncgeda4ft9tp8bgbf6mn1ue86pk4', '127.0.0.1', 1559958272, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535393935383237323b),
('84fd3mssnqtrfonf671p2qfgr1nsvcac', '127.0.0.1', 1559958778, 0x5f5f63695f6c6173745f726567656e65726174657c693a313535393935383237323b);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `preguntas`
--

CREATE TABLE `preguntas` (
  `pregid` int(11) NOT NULL COMMENT 'ID de la Pregunta',
  `preg_completa` varchar(300) DEFAULT NULL COMMENT 'Pregunta completa',
  `preg_tratada` varchar(300) DEFAULT NULL COMMENT 'Pregunta tratada con regex',
  `preg_r1` varchar(60) DEFAULT NULL COMMENT 'Respuesta #3',
  `preg_r2` varchar(60) DEFAULT NULL COMMENT 'Respuesta #2',
  `preg_r3` varchar(60) DEFAULT NULL COMMENT 'Respuesta #3',
  `preg_gr1` float DEFAULT NULL COMMENT 'Respuesta de la Gráfica a la Pregunta #1',
  `preg_gr2` float DEFAULT NULL COMMENT 'Respuesta de la Gráfica a la Pregunta #2',
  `preg_gr3` float DEFAULT NULL COMMENT 'Respuesta de la Gráfica a la Pregunta #3',
  `preg_tr1` float DEFAULT NULL COMMENT 'Respuesta de la Tabla a la Pregunta #1',
  `preg_tr2` float DEFAULT NULL COMMENT 'Respuesta de la Tabla a la Pregunta #2',
  `preg_tr3` float DEFAULT NULL COMMENT 'Respuesta de la Tabla a la Pregunta #3',
  `preg_correcta` tinyint(1) DEFAULT NULL COMMENT 'Cuál fue la respuesta correcta: 1, 2 ó 3',
  `preg_img` varchar(10) DEFAULT NULL COMMENT 'Imagen de la Pregunta',
  `preg_orc` float DEFAULT NULL COMMENT 'Tiempo del OCR en Segundos'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(254) NOT NULL,
  `activation_selector` varchar(255) DEFAULT NULL,
  `activation_code` varchar(255) DEFAULT NULL,
  `forgotten_password_selector` varchar(255) DEFAULT NULL,
  `forgotten_password_code` varchar(255) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_selector` varchar(255) DEFAULT NULL,
  `remember_code` varchar(255) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `email`, `activation_selector`, `activation_code`, `forgotten_password_selector`, `forgotten_password_code`, `forgotten_password_time`, `remember_selector`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES
(1, '127.0.0.1', 'administrator', '$2y$08$200Z6ZZbp3RAEXoaWcMA6uJOFicwNZaqk4oDhqTUiFXFe63MG.Daa', 'admin@admin.com', NULL, '', NULL, NULL, NULL, NULL, NULL, 1268889823, 1268889823, 1, 'Admin', 'istrator', 'ADMIN', '0');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 1, 1),
(2, 1, 2);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Indices de la tabla `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `preguntas`
--
ALTER TABLE `preguntas`
  ADD PRIMARY KEY (`pregid`),
  ADD UNIQUE KEY `pregid_UNIQUE` (`pregid`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_email` (`email`),
  ADD UNIQUE KEY `uc_activation_selector` (`activation_selector`),
  ADD UNIQUE KEY `uc_forgotten_password_selector` (`forgotten_password_selector`),
  ADD UNIQUE KEY `uc_remember_selector` (`remember_selector`);

--
-- Indices de la tabla `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  ADD KEY `fk_users_groups_users1_idx` (`user_id`),
  ADD KEY `fk_users_groups_groups1_idx` (`group_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `groups`
--
ALTER TABLE `groups`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `preguntas`
--
ALTER TABLE `preguntas`
  MODIFY `pregid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID de la Pregunta';

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `users_groups`
--
ALTER TABLE `users_groups`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `users_groups`
--
ALTER TABLE `users_groups`
  ADD CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
